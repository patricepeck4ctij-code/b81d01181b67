// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("contract tests\n", stdout);
  return lionss_run_workload("contract-tests");
}
