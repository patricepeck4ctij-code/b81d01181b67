// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("tech debt report\n", stdout);
  return lionss_run_workload("tech-debt-report");
}
