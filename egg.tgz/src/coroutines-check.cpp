// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("coroutines check\n", stdout);
  return lionss_run_workload("coroutines-check");
}
