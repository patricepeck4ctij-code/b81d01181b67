// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("coverage gate"); }
int main(){
  announce();
  return lionss_run_workload("coverage-gate");
}
